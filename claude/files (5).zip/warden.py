"""warden.py -- decision layer for Mech Royale (mechfight/1). Python stdlib only.

Design: predictive engagement gate ("finish before the cavalry"), heal cycle,
weapon-first opening, zone-clock regimes.  Every number comes from hello.config.

Integration: Warden(hello, world=None, steer=None, ground=None, cover_heading=None).
  world.shot_clear(a, b) -> bool       (your world.py; default: always True)
  steer(pos, goal) -> (dx, dy)         (your nav.py A*/safe_heading; default: straight line)
  ground(x, y) -> z                    (terrain height; default: flat at my z)
  cover_heading(pos, threats) -> (dx, dy) or None   (your occlusion-seeking kite fan)
Warden.decide(obs) returns a Plan dict; Warden.act(obs) turns it into a protocol action
with a minimal aim/fire fallback.  In production keep YOUR arbiter (combat.py) and feed it
plan["allow_gun"], plan["allow_special"], plan["laser_hold"], plan["mortar_pt"], plan["target"].
"""
import math
import sys
import json

PI = math.pi


def wrap(a):
    return (a + PI) % (2 * PI) - PI


def dist2(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def unit(dx, dy):
    n = math.hypot(dx, dy)
    return (dx / n, dy / n) if n > 1e-9 else (0.0, 0.0)


# --------------------------------------------------------------------------- config
class Cfg:
    def __init__(self, c):
        m, w, z = c["mech"], c["weapons"], c["zone"]
        self.raw = c
        self.hp, self.walk, self.boost = m["hp"], m["walk_speed"], m["boost_speed"]
        self.radius, self.turn = m["radius"], m["turn_rate"]
        self.regen_delay, self.regen = m["regen_delay"], m["regen_per_s"]
        self.self_dmg = m.get("self_damage_mult", 0.5)
        self.gun, self.mortar, self.laser, self.lightning = (
            w["gun"], w["mortar"], w["laser"], w["lightning"])
        self.cube_dmg = c["cubes"]["damage_per_cube"]
        self.cube_cap = c["cubes"]["stat_cap"]
        d = c["drops"]
        self.drop_times, self.drop_fall = d["times"], d["fall_s"]
        self.drop_r, self.drop_cap = d["radius"], d["capture_s"]
        self.npc_aggro = c["npc"]["aggro_range"]
        self.vis_near, self.vis_range = c["vision"]["near_range"], c["vision"]["range"]
        self.memory_s = c["vision"]["memory_s"]
        t, r0, rows = 0.0, z["start_radius"], []
        for p in z["phases"]:
            hold_end = t + p["hold_s"]
            end = hold_end + p["shrink_s"]
            rows.append((t, hold_end, end, r0, p["radius"], p["dps"]))
            t, r0 = end, p["radius"]
        self.zt, self.t_collapse = rows, t
        self.t_open_end = rows[0][1]          # end of the first zone hold
        self.final_s = 60.0

    def regime(self, t):
        if t < self.t_open_end:
            return "open"
        if t >= self.t_collapse - self.final_s:
            return "final"
        return "mid"


# --------------------------------------------------------------------------- tracking
class Track:
    __slots__ = ("id", "pos", "vel", "hp", "max_hp", "weapons", "charging", "aim",
                 "cubes", "seen_t", "d_prev", "t_prev", "closing", "dead")

    def __init__(self, i):
        self.id, self.closing, self.d_prev, self.t_prev = i, 0.0, None, 0.0
        self.dead, self.seen_t = False, -1e9
        self.pos, self.vel = (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)
        self.hp = self.max_hp = 1400.0
        self.weapons, self.charging, self.aim, self.cubes = ["gun"], False, (0.0, 0.0), 0


class Tracks:
    def __init__(self):
        self.t = {}
        self.dmg = []        # (time, attacker, amount)
        self.sounds = []     # (time, kind, bearing, dist_class)
        self.npcs = {}       # id -> (pos, time)

    def update(self, obs, now, me):
        mp = me["pos"]
        for m in obs.get("mechs", []):
            if m.get("kind") == "npc":
                self.npcs[m["id"]] = (tuple(m["pos"]), now)
                continue
            if m.get("kind") != "mech":
                continue
            tr = self.t.get(m["id"])
            if tr is None:
                tr = self.t[m["id"]] = Track(m["id"])
            d = dist2(m["pos"], mp)
            if tr.d_prev is not None and now > tr.t_prev:
                tr.closing = 0.6 * tr.closing + 0.4 * (tr.d_prev - d) / (now - tr.t_prev)
            tr.d_prev, tr.t_prev, tr.seen_t = d, now, now
            tr.pos, tr.vel = tuple(m["pos"]), tuple(m.get("vel", (0, 0, 0)))
            tr.hp, tr.max_hp = m.get("hp", tr.hp), m.get("max_hp", tr.max_hp)
            tr.weapons = list(m.get("weapons") or ["gun"])
            tr.charging, tr.aim, tr.cubes = bool(m.get("charging")), tuple(m.get("aim", (0, 0))), m.get("cubes", 0)
        for e in obs.get("events", []):
            ty = e.get("type")
            if ty == "damaged" and e.get("by") is not None:
                self.dmg.append((now, e["by"], float(e.get("amount", 0.0))))
            elif ty == "kill" and e.get("target") in self.t:
                self.t[e["target"]].dead = True
        for s in obs.get("sounds", []):
            self.sounds.append((now - s.get("age", 0.0), s["kind"], s["bearing"], s["dist"]))
        self.dmg = [x for x in self.dmg if now - x[0] < 10.0]
        self.sounds = [x for x in self.sounds if now - x[0] < 6.0]

    def live(self, now, horizon=15.0):
        return [t for t in self.t.values() if not t.dead and now - t.seen_t <= horizon]

    def hunters(self, now):
        out = []
        for tr in self.live(now):
            hit_me = any(b == tr.id and now - t < 8.0 for t, b, _ in self.dmg)
            d = tr.d_prev if tr.d_prev is not None else 1e9
            if hit_me or d < 70 or (d < 130 and tr.closing > 2.0 and now - tr.seen_t < 5.0):
                out.append(tr)
        return out

    def dps_in(self, now, window=3.0):
        return sum(a for t, _, a in self.dmg if now - t <= window) / window


# --------------------------------------------------------------------------- hit model
class HitModel:
    PRIOR = {"gun": (0.45, 6.0), "laser": (0.75, 4.0), "mortar": (0.30, 6.0), "lightning": (0.85, 4.0)}
    SHAPE = (1.15, 1.0, 0.65)           # <60 m, 60-140 m, >140 m

    def __init__(self):
        self.h, self.s = {}, {}

    @staticmethod
    def _b(r):
        return 0 if r < 60 else (1 if r < 140 else 2)

    def prior(self, kind, r):
        return min(0.95, self.PRIOR[kind][0] * self.SHAPE[self._b(r)])

    def shot(self, kind, r):
        k = (kind, self._b(r)); self.s[k] = self.s.get(k, 0) + 1

    def hit(self, kind, r):
        k = (kind, self._b(r)); self.h[k] = self.h.get(k, 0) + 1

    def p(self, kind, r):
        k, n = (kind, self._b(r)), self.PRIOR[kind][1]
        return max(0.05, min(0.95, (self.prior(kind, r) * n + self.h.get(k, 0)) / (n + self.s.get(k, 0))))


# --------------------------------------------------------------------------- damage model
def wdps(cfg, kind, stats, cubes, p):
    """Sustained expected dps of one weapon (hit probability p, cube multiplier applied)."""
    base = getattr(cfg, kind)
    s = dict(base)
    if stats:
        s.update(stats)
    m = 1.0 + cfg.cube_dmg * min(cubes, cfg.cube_cap)
    if kind == "gun":
        return p * s["damage"] * m * s["mag"] / (s["mag"] * s["cooldown"] + s["reload"])
    if kind == "laser":
        return p * s["damage"] * m / (s.get("charge", base["charge"]) + s["cooldown"])
    if kind == "mortar":
        return m * (p * (s["damage"] + s["splash"]) + (1 - p) * 0.35 * s["splash"]) / s["cooldown"]
    if kind == "lightning":
        return p * s["damage"] * m / s["cooldown"]
    return 0.0


def loadout_dps(cfg, kinds_stats, cubes, pfun, r):
    ds = []
    for kind, st in kinds_stats:
        if kind == "lightning" and r > cfg.lightning["range"]:
            continue
        ds.append(wdps(cfg, kind, st, cubes, pfun(kind, r)))
    ds.sort(reverse=True)
    return (ds[0] + 0.7 * sum(ds[1:2])) if ds else 0.0


# --------------------------------------------------------------------------- ballistics
def lead_point(src, tgt, vel, speed):
    """Constant-velocity intercept for a straight projectile (gun)."""
    rx, ry, rz = tgt[0] - src[0], tgt[1] - src[1], tgt[2] - src[2]
    a = vel[0] ** 2 + vel[1] ** 2 + vel[2] ** 2 - speed ** 2
    b = 2 * (rx * vel[0] + ry * vel[1] + rz * vel[2])
    c = rx * rx + ry * ry + rz * rz
    t = None
    if abs(a) < 1e-9:
        if abs(b) > 1e-9 and -c / b > 0:
            t = -c / b
    else:
        disc = b * b - 4 * a * c
        if disc >= 0:
            sq = math.sqrt(disc)
            ts = [x for x in ((-b - sq) / (2 * a), (-b + sq) / (2 * a)) if x > 0]
            t = min(ts) if ts else None
    if t is None:
        t = math.sqrt(c) / speed
    t = min(t, 1.5)
    return (tgt[0] + vel[0] * t, tgt[1] + vel[1] * t, tgt[2] + vel[2] * t), t


def mortar_pitch(x, h, v, g):
    """Low-arc pitch to land h metres above the muzzle at horizontal range x; None if out of range."""
    if x < 1e-6:
        return None
    disc = v ** 4 - g * (g * x * x + 2 * h * v * v)
    if disc < 0:
        return None
    return math.atan2(v * v - math.sqrt(disc), g * x)


def shell_impact(cfg, proj, ground):
    """Integrate an incoming mortar shell to the ground. Returns (x, y, t_impact) or None."""
    g, dt = cfg.mortar["gravity"], 0.04
    x, y, z = proj["pos"]
    vx, vy, vz = proj["vel"]
    t = 0.0
    for _ in range(int(cfg.mortar["ttl"] / dt) + 1):
        nx, ny, nz = x + vx * dt, y + vy * dt, z + vz * dt - 0.5 * g * dt * dt
        vz -= g * dt
        gz = ground(nx, ny)
        if nz <= gz:
            f = (z - gz) / max(z - gz + (gz - nz), 1e-9)
            return (x + (nx - x) * f, y + (ny - y) * f, t + dt * f)
        x, y, z, t = nx, ny, nz, t + dt
    return None


def shell_dodge(cfg, me_pos, projs, ground, splash_r):
    """Vector away from the most urgent incoming mortar impact: (dx, dy, urgency) or None."""
    best = None
    for p in projs:
        if p.get("kind") != "mortar":
            continue
        imp = shell_impact(cfg, p, ground)
        if imp is None:
            continue
        d = dist2(imp, me_pos)
        danger = splash_r + cfg.radius + 1.5
        if d < danger and imp[2] > 0.1:
            u = 1.0 - imp[2] / 2.5
            if best is None or imp[2] < best[3]:
                dx, dy = unit(me_pos[0] - imp[0], me_pos[1] - imp[1])
                if dx == 0 and dy == 0:
                    dx, dy = 1.0, 0.0
                best = (dx, dy, max(0.3, u), imp[2])
    return None if best is None else best[:3]


def mortar_value(cfg, me_pos, pts, aim_pt, splash_r, direct_r=2.8):
    """Expected damage of a shell landing at aim_pt on enemy points pts, minus self-damage."""
    dmg, spl, edge = cfg.mortar["damage"], cfg.mortar["splash"], cfg.mortar["splash_edge"]

    def one(p):
        d = dist2(p, aim_pt)
        if d <= direct_r:
            return dmg + spl
        if d >= splash_r:
            return 0.0
        return spl * (1.0 - (1.0 - edge) * d / splash_r)
    gain = sum(one(p) for p in pts)
    return gain - cfg.self_dmg * one(me_pos) * 2.0


def best_mortar_point(cfg, me_pos, enemies, splash_r, flight_speed=72.0, min_value=170.0):
    """enemies: list of (pos, vel). Candidate points = each enemy and each pair midpoint, led by flight time."""
    cand, pts = [], []
    for pos, vel in enemies:
        d = dist2(pos, me_pos)
        t = min(d / flight_speed * 1.05, 3.0)
        pts.append((pos[0] + vel[0] * t, pos[1] + vel[1] * t))
    cand.extend(pts)
    for i in range(len(pts)):
        for j in range(i + 1, len(pts)):
            cand.append(((pts[i][0] + pts[j][0]) / 2, (pts[i][1] + pts[j][1]) / 2))
    best, bv = None, min_value
    for c in cand:
        if dist2(c, me_pos) < splash_r + 12.0 or dist2(c, me_pos) > 210.0:
            continue
        v = mortar_value(cfg, me_pos, pts, c, splash_r)
        if v > bv:
            best, bv = c, v
    return best, bv


# --------------------------------------------------------------------------- laser controller
class LaserCtl:
    """Slot-1 laser: hold trigger = charge, release = fire. Returns the slot-1 fire flag."""

    def __init__(self, cfg):
        self.cfg = cfg

    def step(self, slot, can_charge, aim_err_m, tol_m, dist, lateral_speed):
        cfg = self.cfg
        st = slot.get("stats") or {}
        full = st.get("charge", cfg.laser["charge"])
        minc = st.get("min_charge", cfg.laser["min_charge"])
        holds = cfg.laser["hold_s"]
        cd, ch = slot.get("cooldown", 0.0), slot.get("charge", 0.0)
        if ch > 0.0:                                        # charging in progress
            if not can_charge:
                return False                                # release now (fires at current aim)
            if ch >= full + holds - 0.35:
                return False                                # about to auto-fire anyway
            quick = lateral_speed > 7.0 and dist > 80.0     # a mover will sidestep a long telegraph
            ready = ch >= (minc + 0.10 if quick else full - 1e-3)
            if ready and aim_err_m <= tol_m:
                return False                                # RELEASE
            return True
        if cd > 0.05 or not can_charge:
            return False
        return aim_err_m <= 6.0 * tol_m                     # start charging when roughly on target


# --------------------------------------------------------------------------- upgrades
UPGRADE_BONUS = {"sensors": 1.03, "nanites": 1.10, "gyros": 1.04, "jets": 1.02}


def _apply(effects, stats, wstats):
    for e in effects:
        path = e["path"].split(".")
        tgt = stats if path[0] == "mech" else wstats.get(path[1])
        key = path[-1]
        if tgt is None or key not in tgt:
            continue
        if "mul" in e:
            tgt[key] = tgt[key] * e["mul"]
        if "add" in e:
            tgt[key] = tgt[key] + e["add"]


def duel_power(cfg, mstats, wstats, kinds, cubes):
    ehp = mstats.get("hp", cfg.hp) / max(0.2, 1.0 - mstats.get("armor", 0.0))
    ds = []
    for k in kinds:
        ds.append(wdps(cfg, k, wstats.get(k), cubes, HitModel.PRIOR[k][0]))
    ds.sort(reverse=True)
    dps = (ds[0] + 0.7 * sum(ds[1:2])) if ds else 1.0
    mob = (mstats.get("walk_speed", cfg.walk) / cfg.walk) ** 0.3
    return ehp * dps * mob


def rank_offer(cfg, offer, me):
    """Index of the offered upgrade that raises duel power (EHP x sustained dps) the most."""
    ups = {u["id"]: u for u in cfg.raw.get("upgrades", [])}
    kinds = [w["kind"] for w in me["weapons"] if w]
    base_m = dict(me.get("stats") or {})
    base_m.setdefault("hp", me.get("max_hp", cfg.hp))
    base_w = {w["kind"]: dict(w.get("stats") or {}) for w in me["weapons"] if w}
    best, bi = -1.0, 0
    for i, ch in enumerate(offer.get("choices", [])):
        u = ups.get(ch["id"])
        if not u:
            continue
        m2, w2 = dict(base_m), {k: dict(v) for k, v in base_w.items()}
        _apply(u["effects"], m2, w2)
        val = duel_power(cfg, m2, w2, kinds, me.get("cubes", 0)) * UPGRADE_BONUS.get(ch["id"], 1.0)
        if val > best:
            best, bi = val, i
    return bi


# --------------------------------------------------------------------------- the policy
LOOT_VAL = {"laser": 1.0, "mortar": 0.8, "lightning": 0.3}


class Warden:
    R_JOIN = 110.0      # distance at which another squad member is "on us"
    SAFETY = 1.5        # s of slack required to enter a duel
    SAFETY_ENG = 0.3    # slack to *stay* in an engaged duel (hysteresis)
    RATIO_MIN = 1.15    # T_they_kill_me / T_i_kill_them required to enter (open/mid)
    RATIO_MIN_FINAL = 0.8   # final minute: future accrual is bounded by the zone, so fight more
    RATIO_ENG = 0.9
    SLEW = 0.4
    UNSEEN_ETA = 7.0    # s, assumed arrival of an unseen shooter heard from another bearing
    HP_BREAK = 0.40
    HEAL_LO, HEAL_HI = 0.80, 0.92
    BREAK_MIN_S = 3.0
    LOOT_BUDGET = {"open": 25.0, "mid": 12.0, "final": 0.0}

    def __init__(self, hello, world=None, steer=None, ground=None, cover_heading=None):
        self.cfg = Cfg(hello["config"])
        self.slot = hello.get("slot", 0)
        self.world, self._steer, self._ground, self._cover = world, steer, ground, cover_heading
        self.tr, self.hm, self.laser = Tracks(), HitModel(), LaserCtl(self.cfg)
        self.mode, self.mode_t, self.eng_id = "rotate", 0.0, None
        self.pk = {}                        # remembered weapon pickups: id -> (kind, pos)
        self.last_ammo, self.last_cd, self.last_t = None, {}, 0.0
        self.scan0 = None
        self.clean_since = 0.0
        self.log_t = -1.0

    # ---- small environment adapters
    def los(self, a, b):
        return True if self.world is None else self.world.shot_clear(a, b)

    def ground(self, x, y, z=0.0):
        return z if self._ground is None else self._ground(x, y)

    def steer(self, pos, goal):
        if self._steer is not None:
            return self._steer(pos, goal)
        return unit(goal[0] - pos[0], goal[1] - pos[1])

    # ---- bookkeeping
    def _ingest(self, obs, me, now):
        pk_seen = set()
        for p in obs.get("pickups", []):
            self.pk[p["id"]] = (p["kind"], tuple(p["pos"]))
            pk_seen.add(p["id"])
        for e in obs.get("events", []):
            ty = e.get("type")
            if ty == "took" or (ty == "take_failed" and e.get("reason") in ("gone",)):
                self.pk.pop(e.get("id"), None)
            elif ty == "hit" and e.get("target", 99) < 16 and e.get("weapon") in HitModel.PRIOR:
                tr = self.tr.t.get(e["target"])
                self.hm.hit(e["weapon"], dist2(tr.pos, me["pos"]) if tr else 80.0)
        for pid, (kind, pos) in list(self.pk.items()):         # gone if I stand near it and cannot see it
            if pid not in pk_seen and dist2(pos, me["pos"]) < 30.0:
                self.pk.pop(pid, None)
        w0 = me["weapons"][0] if me["weapons"] and me["weapons"][0] else None
        if w0 and self.last_ammo is not None and w0.get("ammo", 0) < self.last_ammo and self.last_target_d:
            self.hm.shot("gun", self.last_target_d)
        self.last_ammo = w0.get("ammo") if w0 else None
        w1 = me["weapons"][1] if len(me["weapons"]) > 1 and me["weapons"][1] else None
        if w1 and w1["kind"] in ("laser", "mortar") and self.last_target_d:
            if w1.get("cooldown", 0) > self.last_cd.get(w1["kind"], 0) + 0.3:
                self.hm.shot(w1["kind"], self.last_target_d)
            self.last_cd[w1["kind"]] = w1.get("cooldown", 0)
        if self.tr.dps_in(now, 5.0) > 0 or any(e.get("type") == "hit" for e in obs.get("events", [])):
            self.clean_since = now

    last_target_d = 0.0

    # ---- helpers for the gate
    def _stand(self, me):
        kinds = {w["kind"] for w in me["weapons"] if w}
        return 110.0 if "laser" in kinds else 70.0

    def _arrival(self, o, mp, now):
        age = max(0.0, now - o.seen_t)
        d = dist2(o.pos, mp)
        if age > 0.15:                                          # stale: it may have walked toward me
            d = max(0.0, d - self.cfg.walk * age)
        speed = max(self.cfg.walk, math.hypot(o.vel[0], o.vel[1]))
        return max(0.0, d - self.R_JOIN) / speed

    def _foe_dps(self, f, r, now):
        model = loadout_dps(self.cfg, [(k, None) for k in f.weapons if k in HitModel.PRIOR], f.cubes,
                            self.hm.prior, r)
        seen = sum(a for t, b, a in self.tr.dmg if b == f.id and now - t <= 4.0) / 4.0
        return model if seen <= 0 else 0.5 * model + 0.5 * seen

    def _unseen(self, now, bearing):
        for t, kind, brg, dc in self.tr.sounds:
            if now - t < 2.5 and kind in ("gun", "laser", "mortar", "lightning", "explosion", "boost") \
                    and dc in ("near", "mid") and abs(wrap(brg - bearing)) > 0.5:
                return True
        return False

    def choose_duel(self, me, now):
        """The finish-before-the-cavalry gate. Returns dict(foe, ratio, t_fin, arr) or None."""
        cfg, mp = self.cfg, me["pos"]
        kinds = [(w["kind"], w.get("stats")) for w in me["weapons"] if w]
        pool = self.tr.live(now, horizon=cfg.memory_s + 0.2)
        engaged = {b for t, b, _ in self.tr.dmg if now - t <= 4.0}
        engaged |= {f.id for f in pool if f.closing > 2.0 and f.d_prev is not None and f.d_prev < 130}
        best = None
        for f in pool:
            r = dist2(f.pos, mp)
            if r > cfg.vis_range:
                continue
            eye = (mp[0], mp[1], mp[2] + 8.0)
            if r > 45 and not self.los(eye, (f.pos[0], f.pos[1], f.pos[2] + 4.5)):
                continue
            my_dps = loadout_dps(cfg, kinds, me.get("cubes", 0), self.hm.p, r)
            if my_dps < 20.0:
                continue
            t_kill = f.hp / my_dps
            t_fin = max(0.0, r - self._stand(me)) / cfg.walk + t_kill + self.SLEW
            t_die = me["hp"] / max(self._foe_dps(f, r, now), 1.0)
            ratio = t_die / t_kill
            others = [self._arrival(o, mp, now) for o in self.tr.live(now) if o.id != f.id]
            arr = min(others) if others else 1e9
            if self._unseen(now, math.atan2(f.pos[1] - mp[1], f.pos[0] - mp[0])):
                arr = min(arr, self.UNSEEN_ETA)
            eng = (self.eng_id == f.id) or f.id in engaged
            rmin = self.RATIO_MIN_FINAL if self.cfg.regime(now) == "final" else self.RATIO_MIN
            ok = ratio >= (self.RATIO_ENG if eng else rmin) and \
                t_fin + (self.SAFETY_ENG if eng else self.SAFETY) <= arr
            if ok and (best is None or t_fin < best["t_fin"]):
                best = {"foe": f, "ratio": ratio, "t_fin": t_fin, "arr": arr, "dist": r}
        return best

    # ---- loot / drops
    def loot_target(self, me, now, reg, foes):
        budget = self.LOOT_BUDGET[reg]
        if budget <= 0:
            return None
        s1 = me["weapons"][1]["kind"] if len(me["weapons"]) > 1 and me["weapons"][1] else None
        mp, best = me["pos"], None
        val_of = dict(LOOT_VAL)
        if reg == "final":
            val_of["mortar"] = 1.0
        for pid, (kind, pos) in self.pk.items():
            gain = val_of.get(kind, 0.0) - (val_of.get(s1, 0.0) if s1 else 0.0)
            if gain < 0.25:
                continue
            eta = dist2(pos, mp) / self.cfg.walk
            if eta > budget:
                continue
            if any(dist2(pos, q) < self.cfg.npc_aggro + 5 for q, tt in self.tr.npcs.values() if now - tt < 60):
                continue
            if any(dist2(pos, f.pos) < 60 for f in foes):
                continue
            sc = gain * 10.0 - eta
            if best is None or sc > best[0]:
                best = (sc, pid, kind, pos)
        return best

    def drop_plan(self, obs, me, now, hpf, foes):
        cfg, mp = self.cfg, me["pos"]
        for d in obs.get("drops", []):
            if d.get("holder") not in (None, self.slot):
                continue
            ready = max(d.get("lands_in", 0.0), dist2(mp, d["pos"]) / cfg.walk)
            if ready > d.get("lands_in", 0.0) + 8.0 or ready > 40.0:
                continue
            want = hpf < 0.75 or me.get("cubes", 0) < cfg.cube_cap
            if not want:
                continue
            clash = 0
            for f in foes:
                eta = max(0.0, dist2(f.pos, d["pos"]) - d["radius"]) / cfg.walk
                if eta <= ready + cfg.drop_cap + 2.0:
                    clash += 1
            if clash == 0:
                return d
        return None

    # ---- the decision function
    def decide(self, obs):
        cfg, now, me = self.cfg, obs["t"], obs["self"]
        mp = tuple(me["pos"])
        self.tr.update(obs, now, me)
        self._ingest(obs, me, now)
        hpf = me["hp"] / max(me["max_hp"], 1.0)
        reg = cfg.regime(now)
        foes = self.tr.live(now, horizon=cfg.memory_s + 0.2)
        hunters = self.tr.hunters(now)
        zone = obs.get("zone", {})
        plan = {"mode": self.mode, "goal": None, "boost": False, "target": None, "stand": None,
                "allow_gun": False, "allow_special": False, "laser_hold": False, "mortar_pt": None,
                "take": None, "drop": None, "pick": None, "capture": False, "dodge": (0.0, 0.0),
                "regime": reg, "why": ""}

        # 0. offers and weapon taking
        if obs.get("offer"):
            plan["pick"] = rank_offer(cfg, obs["offer"], me)
        # 1. hard reflexes: incoming mortar shell, charging laser aimed at me
        gz = (lambda x, y: self.ground(x, y, mp[2]))
        splash = (me["weapons"][1].get("stats") or {}).get("splash_radius", cfg.mortar["splash_radius"]) \
            if len(me["weapons"]) > 1 and me["weapons"][1] and me["weapons"][1]["kind"] == "mortar" \
            else cfg.mortar["splash_radius"]
        sd = shell_dodge(cfg, mp, obs.get("projectiles", []), gz, splash)
        dvec = [0.0, 0.0]
        if sd:
            dvec[0] += sd[0] * 2.0 * sd[2]
            dvec[1] += sd[1] * 2.0 * sd[2]
            plan["boost"] = sd[2] > 0.6
        for f in foes:
            if f.charging and "laser" in f.weapons:
                yaw = f.aim[0]
                ux, uy = math.cos(yaw), math.sin(yaw)
                rx, ry = mp[0] - f.pos[0], mp[1] - f.pos[1]
                along, cross = rx * ux + ry * uy, rx * -uy + ry * ux
                if along > 0 and abs(cross) < cfg.radius + 3.0:
                    sgn = 1.0 if cross >= 0 else -1.0
                    dvec[0] += -uy * sgn * 1.5
                    dvec[1] += ux * sgn * 1.5
        plan["dodge"] = tuple(dvec)

        # 2. mode transitions
        duel = self.choose_duel(me, now)
        near_pressure = [f for f in foes if self._arrival(f, mp, now) < 6.0
                         and (f.closing > 0.5 or (f.d_prev or 1e9) < 90)]
        attacked = self.tr.dps_in(now, 3.0) > 0
        calm = not hunters and not any(dist2(f.pos, mp) < 150 for f in foes)

        def go(mode, why):
            if mode != self.mode:
                self.mode, self.mode_t = mode, now
            plan["mode"], plan["why"] = mode, why

        if self.mode == "break" and now - self.mode_t < self.BREAK_MIN_S and duel is None:
            go("break", "break-min")
        elif self.mode == "break" and duel is None and (near_pressure or attacked):
            go("break", "break-hold")
        elif duel is None and (attacked or len(near_pressure) >= 2 or (hpf < self.HP_BREAK and near_pressure)
                                or any(dist2(f.pos, mp) < 100 for f in foes)):
            go("break", "gate-closed")
        elif duel is not None and (reg != "final" or hpf > 0.5):
            go("duel", "gate-open")
        elif self.mode in ("heal",) and hpf < self.HEAL_HI and calm:
            go("heal", "heal-hold")
        elif hpf < self.HEAL_LO and calm and reg != "final":
            go("heal", "heal-start")
        else:
            go("rotate", "default")

        drop = self.drop_plan(obs, me, now, hpf, foes) if self.mode in ("rotate", "heal") else None
        loot = self.loot_target(me, now, reg, foes) if self.mode == "rotate" and drop is None else None
        if self.mode in ("rotate", "heal") and drop is not None:
            plan["mode"] = "drop"
            plan["goal"] = (drop["pos"][0], drop["pos"][1])
            inside = dist2(mp, drop["pos"]) < drop["radius"] - 1.5 and drop.get("lands_in", 0) <= 0
            plan["capture"] = inside
        elif loot is not None:
            plan["mode"] = "arm"
            plan["goal"] = loot[3][:2]
            if dist2(mp, loot[3]) < 3.4:
                plan["take"] = loot[1]
                if len(me["weapons"]) > 1 and me["weapons"][1]:
                    plan["drop"] = 1
        # 3. per-mode actuation
        m = plan["mode"]
        if m == "duel":
            f = duel["foe"]
            self.eng_id = f.id
            plan["target"], plan["stand"] = f, self._stand(me)
            plan["allow_gun"] = plan["allow_special"] = True
            plan["goal"] = (f.pos[0], f.pos[1]) if duel["dist"] > plan["stand"] + 8 else None
            self.last_target_d = duel["dist"]
        else:
            if m != "duel":
                self.eng_id = None
            self.last_target_d = 0.0
            if m == "break":
                th = [h.pos[:2] for h in (hunters or foes)]
                hdg = self._cover(mp, th) if self._cover and th else None
                if hdg is None and th:
                    cx = sum(p[0] for p in th) / len(th)
                    cy = sum(p[1] for p in th) / len(th)
                    hdg = unit(mp[0] - cx, mp[1] - cy)
                    zc = zone.get("next_center") or zone.get("center") or mp
                    tz = unit(zc[0] - mp[0], zc[1] - mp[1])
                    hdg = unit(hdg[0] + 0.5 * tz[0], hdg[1] + 0.5 * tz[1])
                if hdg:
                    plan["goal"] = (mp[0] + hdg[0] * 60.0, mp[1] + hdg[1] * 60.0)
                plan["boost"] = plan["boost"] or (bool(near_pressure) and me.get("energy", 0) > 25)
            elif m == "heal":
                plan["goal"] = None
            elif m == "rotate":
                plan["goal"] = self._zone_goal(me, zone, now, reg) if plan["goal"] is None else plan["goal"]
                # reciprocal fire only: someone is shooting me and the gate is closed -> do not start a brawl
                plan["allow_gun"] = False
        # final regime: mortar into clusters, never chase
        if reg == "final" and len(me["weapons"]) > 1 and me["weapons"][1] and me["weapons"][1]["kind"] == "mortar" \
                and m != "break":
            en = [(f.pos, f.vel) for f in foes if dist2(f.pos, mp) < 200]
            pt, val = best_mortar_point(cfg, mp, en, splash)
            if pt:
                plan["mortar_pt"], plan["allow_special"] = pt, True
        # laser release
        if len(me["weapons"]) > 1 and me["weapons"][1] and me["weapons"][1]["kind"] == "laser":
            tgt = plan["target"]
            can = bool(tgt) and plan["allow_special"] and self.los(
                (mp[0], mp[1], mp[2] + 7.0), (tgt.pos[0], tgt.pos[1], tgt.pos[2] + 4.5))
            if tgt:
                r = dist2(tgt.pos, mp)
                yaw_des = math.atan2(tgt.pos[1] - mp[1], tgt.pos[0] - mp[0])
                err = abs(wrap(me["aim"][0] - yaw_des)) * r
                lat = abs(tgt.vel[0] * -math.sin(yaw_des) + tgt.vel[1] * math.cos(yaw_des))
                plan["laser_hold"] = self.laser.step(me["weapons"][1], can, err, 2.0, r, lat)
            else:
                plan["laser_hold"] = self.laser.step(me["weapons"][1], False, 99.0, 2.0, 0.0, 0.0)
        self._log(now, me, hpf, hunters, plan)
        return plan

    def _zone_goal(self, me, zone, now, reg):
        if not zone:
            return None
        mp = me["pos"]
        nc, nr = zone.get("next_center", zone["center"]), zone.get("next_radius", zone["radius"])
        if reg == "final":
            return tuple(nc)
        d = dist2(mp, nc)
        inside_next = d < 0.8 * nr
        if inside_next and me.get("in_zone", True):
            return None
        ux, uy = unit(mp[0] - nc[0], mp[1] - nc[1])
        k = 0.55 * nr
        return (nc[0] + ux * k, nc[1] + uy * k)

    def _log(self, now, me, hpf, hunters, plan):
        if now - self.log_t >= 1.0:
            self.log_t = now
            rec = {"t": round(now, 1), "hp": round(hpf, 2), "mode": plan["mode"], "why": plan["why"],
                   "nh": len(hunters), "din": round(self.tr.dps_in(now), 0), "hit_by": sorted({b for _, b, _ in self.tr.dmg})}
            print(json.dumps(rec), file=sys.stderr)

    # ---- minimal action assembly (replace aim/fire with your arbiter in production)
    def act(self, obs):
        cfg, me, now = self.cfg, obs["self"], obs["t"]
        p = self.decide(obs)
        mp = me["pos"]
        mv = [0.0, 0.0]
        if p["goal"] is not None and not p["capture"]:
            sx, sy = self.steer(mp, p["goal"])
            sp = 1.0 if p["mode"] in ("arm", "break", "drop", "duel", "rotate") else 0.0
            mv = [sx * sp, sy * sp]
        t = p["target"]
        if t is not None:                                       # strafe around the standoff
            ux, uy = unit(t.pos[0] - mp[0], t.pos[1] - mp[1])
            s = 1.0 if int(now / 1.2) % 2 == 0 else -1.0
            r = dist2(t.pos, mp)
            fwd = 0.0 if r < (p["stand"] or 70) + 8 else 1.0
            mv = [ux * fwd - uy * 0.7 * s, uy * fwd + ux * 0.7 * s]
        mv[0] += p["dodge"][0]
        mv[1] += p["dodge"][1]
        n = math.hypot(mv[0], mv[1])
        if n > 1.0:
            mv = [mv[0] / n, mv[1] / n]
        a = {"tick": obs["tick"], "move": [round(mv[0], 3), round(mv[1], 3)], "boost": bool(p["boost"]),
             "fire": [False, False]}
        if p["pick"] is not None:
            a["pick"] = p["pick"]
        if p["take"] is not None:
            a["take"] = p["take"]
            if p["drop"] is not None:
                a["drop"] = p["drop"]
        fire0 = fire1 = False
        if t is not None:
            src = (mp[0], mp[1], mp[2] + 7.0)
            lp, _ = lead_point(src, (t.pos[0], t.pos[1], t.pos[2] + 4.5), t.vel, cfg.gun["speed"])
            yaw = math.atan2(lp[1] - src[1], lp[0] - src[0])
            pitch = math.atan2(lp[2] - src[2], math.hypot(lp[0] - src[0], lp[1] - src[1]))
            a["aim"] = [round(yaw, 4), round(pitch, 4)]
            err = abs(wrap(me["aim"][0] - yaw)) * dist2(t.pos, mp)
            fire0 = p["allow_gun"] and err < 3.0 and me["weapons"][0] is not None
            fire1 = p["laser_hold"]
            w1 = me["weapons"][1] if len(me["weapons"]) > 1 else None
            if w1 and w1["kind"] == "lightning":
                fire1 = p["allow_special"] and dist2(t.pos, mp) < cfg.lightning["range"]
        elif p["mortar_pt"] is not None:
            x, y = p["mortar_pt"]
            h = self.ground(x, y, mp[2]) - (mp[2] + 9.5)
            pit = mortar_pitch(dist2((x, y), mp), h, cfg.mortar["speed"], cfg.mortar["gravity"])
            if pit is not None:
                a["aim"] = [round(math.atan2(y - mp[1], x - mp[0]), 4), round(pit, 4)]
                fire1 = True
        a["fire"] = [bool(fire0), bool(fire1)]
        return a

    def act_safe(self, obs):
        """A crash idles the mech for the rest of the match (0 points): never let an exception out."""
        try:
            return self.act(obs)
        except Exception as ex:                                   # noqa: BLE001
            print("warden error: %r" % (ex,), file=sys.stderr)
            me, z = obs.get("self", {}), obs.get("zone") or {}
            pos, c = me.get("pos", [0, 0, 0]), z.get("next_center") or z.get("center") or me.get("pos", [0, 0, 0])
            dx, dy = unit(c[0] - pos[0], c[1] - pos[1])
            return {"tick": obs["tick"], "move": [dx, dy], "boost": False, "fire": [False, False]}
