import json, math, time, sys, io, contextlib
import os; HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import warden as W

cfg = json.load(open(os.path.join(HERE, 'live_config.json')))
hello = {"type": "hello", "slot": 3, "config": cfg}

def mk_self(pos=(0, 0, 0), hp=1400, aim=(0.0, 0.0), weapons=None, cubes=0, energy=100):
    weapons = weapons if weapons is not None else [
        {"kind": "gun", "cooldown": 0, "ammo": 12, "reload": 0, "stats": dict(cfg["weapons"]["gun"])}, None]
    return {"id": 3, "pos": list(pos), "vel": [0, 0, 0], "aim": list(aim), "hp": hp, "max_hp": 1400,
            "energy": energy, "grounded": True, "cubes": cubes, "upgrades": [], "in_zone": True,
            "weapons": weapons, "stats": {"hp": 1400, "walk_speed": 11.7, "armor": 0.0}}

def mech(i, pos, hp=1400, vel=(0, 0, 0), weapons=("gun",), aim=(0, 0), charging=False):
    return {"id": i, "kind": "mech", "pos": list(pos), "vel": list(vel), "aim": list(aim), "hp": hp,
            "max_hp": 1400, "cubes": 0, "weapons": list(weapons), "charging": charging}

def obs(t, me, mechs=(), **kw):
    o = {"type": "obs", "tick": int(t * 20), "t": t, "alive": 16, "self": me, "mechs": list(mechs),
         "projectiles": [], "pickups": [], "sounds": [], "events": [], "drops": [], "offer": None,
         "zone": {"center": [0, 0], "radius": 560, "next_center": [10, 10], "next_radius": 380,
                  "shrink_start": 60, "shrink_end": 110, "dps": 20}}
    o.update(kw); return o

def run(label, w, o):
    with contextlib.redirect_stderr(io.StringIO()):
        p = w.decide(o)
    print(f"{label:46s} mode={p['mode']:6s} why={p['why']:12s} goal={None if p['goal'] is None else tuple(round(x) for x in p['goal'])} "
          f"tgt={getattr(p['target'],'id',None)} gun={p['allow_gun']} take={p['take']} cap={p['capture']} pick={p['pick']}")
    return p

# --- numbers
print("zone timeline:", [(round(a), round(b), round(c)) for a, b, c, *_ in W.Cfg(cfg).zt], "collapse", W.Cfg(cfg).t_collapse)
c = W.Cfg(cfg)
print("regimes:", c.regime(10), c.regime(100), c.regime(360))
print("gun dps@p=1 %.1f  laser %.1f  mortar(p=.3) %.1f  lightning %.1f" % (
    W.wdps(c, "gun", None, 0, 1), W.wdps(c, "laser", None, 0, 1), W.wdps(c, "mortar", None, 0, .3), W.wdps(c, "lightning", None, 0, 1)))

# S1 opening, laser pickup 60 m away
w = W.Warden(hello)
m = mk_self()
o = obs(1.0, m, pickups=[{"id": 8001, "kind": "laser", "pos": [60, 5, 0]}])
run("S1 opening, laser 60 m away", w, o)
o = obs(5.0, mk_self(pos=(58, 4, 0)), pickups=[{"id": 8001, "kind": "laser", "pos": [60, 5, 0]}])
run("S1b standing on the laser", w, o)

# S2 lone foe
w = W.Warden(hello)
run("S2 lone foe @100m", w, obs(25.0, mk_self(), [mech(5, (100, 0, 0))]))
# S3 two hunters
w = W.Warden(hello)
run("S3 foe@100 + second@125", w, obs(25.0, mk_self(), [mech(5, (100, 0, 0)), mech(6, (0, 125, 0), vel=(0, -8, 0))]))
# S3b second far away
w = W.Warden(hello)
run("S3b foe@100 + second@400 (stale-free)", w, obs(25.0, mk_self(), [mech(5, (100, 0, 0)), mech(6, (0, 400, 0))]))
# S4 low hp, two near
w = W.Warden(hello)
run("S4 hp 35% two near", w, obs(40.0, mk_self(hp=490), [mech(5, (60, 0, 0)), mech(6, (0, 70, 0))]))
# S5 heal: hurt, nobody around
w = W.Warden(hello)
run("S5 hurt 55%, calm", w, obs(80.0, mk_self(hp=770), []))
# S6 incoming shell
w = W.Warden(hello)
shell = {"id": 9, "kind": "mortar", "pos": [-60, 0, 20], "vel": [36, 0, 5]}
o = obs(30.0, mk_self(pos=(0, 0, 0)), projectiles=[shell])
with contextlib.redirect_stderr(io.StringIO()):
    p = w.decide(o)
imp = W.shell_impact(c, shell, lambda x, y: 0.0)
print("S6 shell impact", tuple(round(v, 1) for v in imp), "dodge", tuple(round(v, 2) for v in p["dodge"]))
# S7 laser charging at me
w = W.Warden(hello)
f = mech(5, (150, 0, 0), weapons=("gun", "laser"), aim=(math.pi, 0), charging=True)
with contextlib.redirect_stderr(io.StringIO()):
    p = w.decide(obs(30.0, mk_self(pos=(0, 0.5, 0)), [f]))
print("S7 laser dodge vec", tuple(round(v, 2) for v in p["dodge"]))
# S8 drop
w = W.Warden(hello)
d = {"id": 20000, "pos": [40, 10, 0], "radius": 8, "lands_in": 0.0, "capture_s": 4, "progress": 0, "holder": None}
run("S8 drop 40 m, hp 50%", w, obs(100.0, mk_self(hp=700), drops=[d]))
run("S8b inside ring", w, obs(102.0, mk_self(pos=(40, 10, 0), hp=700), drops=[d]))
# S9 offers
w = W.Warden(hello)
offer = {"id": 1, "expires": 9, "choices": [{"id": "gun_mag"}, {"id": "gun_damage"}, {"id": "armor"}]}
m = mk_self(); m["weapons"][0]["stats"] = dict(cfg["weapons"]["gun"])
for ids in (["gun_mag", "gun_damage", "armor"], ["plating", "servos", "sensors"], ["gun_rate", "nanites", "capacitor"]):
    offer["choices"] = [{"id": i} for i in ids]
    print("S9 offer", ids, "->", ids[W.rank_offer(c, offer, m)])
# S10 laser controller
lc = W.LaserCtl(c)
seq = []
slot = {"kind": "laser", "cooldown": 0.0, "charge": 0.0, "stats": {}}
for k in range(12):
    f = lc.step(slot, True, 1.0, 2.0, 120, 2.0)
    seq.append(int(f))
    slot["charge"] = slot["charge"] + 0.1 if f else 0.0
    if not f and slot["charge"] == 0.0 and k > 0 and seq[-2] == 1:
        slot["cooldown"] = 1.65
print("S10 laser hold/release sequence:", seq)
# S11 mortar cluster
pt, v = W.best_mortar_point(c, (0, 0, 0), [((100, 0, 0), (0, 0, 0)), ((104, 3, 0), (0, 0, 0)), ((98, -4, 0), (0, 0, 0))], 7.0)
print("S11 mortar cluster point", tuple(round(x, 1) for x in pt), "value", round(v))
print("   pitch for 100 m flat: %.1f deg" % math.degrees(W.mortar_pitch(100, 0, 72, 22)))
# S12 lone hunter that is already shooting me (equal guns): must fight, not stand idle
w = W.Warden(hello)
ev = [{"type": "damaged", "amount": 45, "weapon": "gun", "bearing": 0.0, "by": 5}]
run("S12 lone attacker, equal guns", w, obs(30.0, mk_self(), [mech(5, (100, 0, 0))], events=ev))
# S13 attacker holds laser, I only have a gun
w = W.Warden(hello)
run("S13 attacker with laser, I have gun", w, obs(30.0, mk_self(), [mech(5, (100, 0, 0), weapons=("gun", "laser"))], events=ev))
# S14 I hold a laser, lone foe at 150 m, not yet attacking
w = W.Warden(hello)
m = mk_self(weapons=[{"kind": "gun", "cooldown": 0, "ammo": 12, "reload": 0, "stats": dict(cfg["weapons"]["gun"])},
                     {"kind": "laser", "cooldown": 0, "charge": 0.0, "stats": {}}])
run("S14 I hold laser, lone foe @150m", w, obs(50.0, m, [mech(5, (150, 0, 0))]))
run("S14b same + second foe @130m closing", w, obs(50.1, m, [mech(5, (150, 0, 0)), mech(6, (0, 130, 0), vel=(0, -10, 0))]))
# timing
w = W.Warden(hello)
mechs = [mech(i, (80 + 15 * i, (-1) ** i * 30 * i % 200, 0), weapons=("gun", "laser")) for i in range(1, 16)]
t0 = time.perf_counter(); n = 0
with contextlib.redirect_stderr(io.StringIO()):
    for k in range(2000):
        o = obs(10 + k * 0.1, mk_self(pos=(k % 7, 0, 0)), mechs, projectiles=[shell, shell, shell])
        w.act(o); n += 1
dt = (time.perf_counter() - t0) / n * 1000
print("mean decision %.3f ms over %d obs with 15 mechs + 3 shells" % (dt, n))

# ---- fuzz: odd-shaped but protocol-legal observations must never raise out of act_safe, and act must not raise on sane ones
import random
random.seed(7)
w = W.Warden(hello)
bad = 0
with contextlib.redirect_stderr(io.StringIO()):
    for k in range(3000):
        me = mk_self(pos=(random.uniform(-300, 300), random.uniform(-300, 300), random.uniform(-5, 20)),
                     hp=random.uniform(50, 1400), aim=(random.uniform(-3, 3), random.uniform(-.5, 1)),
                     weapons=random.choice([None, [{"kind": "gun", "cooldown": 0.1, "ammo": 5, "reload": 0, "stats": {}}, None],
                                             [{"kind": "gun", "cooldown": 0, "ammo": 12, "reload": 0, "stats": {}},
                                              {"kind": "mortar", "cooldown": 0, "stats": {}}],
                                             [{"kind": "gun", "cooldown": 0, "ammo": 12, "reload": 0, "stats": {}},
                                              {"kind": "laser", "cooldown": 0, "charge": random.choice([0, .3, .8, 2.7]), "stats": {}}]]))
        ms = [mech(i, (random.uniform(-250, 250), random.uniform(-250, 250), 0), hp=random.uniform(100, 1400),
                   vel=(random.uniform(-12, 12), random.uniform(-12, 12), 0),
                   weapons=random.choice([("gun",), ("gun", "laser"), ("gun", "mortar"), ("gun", "lightning")]),
                   aim=(random.uniform(-3, 3), 0), charging=random.random() < .2)
              for i in random.sample([i for i in range(16) if i != 3], random.randint(0, 6))]
        o = obs(random.uniform(0, 430), me, ms)
        if random.random() < .2: o["zone"] = None
        if random.random() < .2: o["events"] = [{"type": "damaged", "amount": 50, "weapon": "gun", "bearing": 0, "by": random.randint(0, 15)}]
        if random.random() < .1: o["offer"] = {"id": 1, "expires": 5, "choices": [{"id": "plating"}, {"id": "armor"}, {"id": "gun_mag"}]}
        try:
            a = w.act_safe(o)
            assert a["tick"] == o["tick"] and len(a["move"]) == 2 and len(a["fire"]) == 2
            json.dumps(a)
        except Exception as ex:
            bad += 1; print("FUZZ FAIL", repr(ex))
            if bad > 3: break
print("fuzz done, failures:", bad)
